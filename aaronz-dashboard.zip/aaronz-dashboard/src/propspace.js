/**
 * PropSpace client. All calls go through the Vite dev middleware at /ps,
 * so there is no token handling in the browser at all.
 *
 * Response envelopes are the one thing worth verifying against your account:
 * the spec defines LeadListResponse but not the exact key names, so unwrap()
 * below is deliberately forgiving. Log a raw response once and tighten it.
 */

const BASE = "/ps";

async function get(path, params = {}) {
  const qs = new URLSearchParams(
    Object.entries(params).filter(([, v]) => v !== undefined && v !== null)
  );
  const url = `${BASE}${path}${qs.toString() ? `?${qs}` : ""}`;
  const res = await fetch(url);
  if (!res.ok) throw new Error(`${path} → ${res.status} ${await res.text()}`);
  return res.json();
}

// Handles { data: [...] } / { leads: [...] } / bare arrays.
const unwrap = (json) =>
  Array.isArray(json) ? json : json.data ?? json.leads ?? json.items ?? [];

export async function fetchLeads({ from, to, perPage = 100, maxPages = 40 }) {
  const all = [];
  for (let page = 1; page <= maxPages; page++) {
    const json = await get("/leads", {
      date_created_from: from,
      date_created_to: to,
      page,
      per_page: perPage,
    });
    const rows = unwrap(json);
    all.push(...rows);
    if (rows.length < perPage) break;
  }
  return all;
}

// Pull the real taxonomy rather than hardcoding statuses.
export const fetchLeadStatuses = () => get("/options/lead-statuses").then(unwrap);
export const fetchLeadSources  = () => get("/options/lead-sources").then(unwrap);
export const fetchAgents       = () => get("/options/agents").then(unwrap);

/* ------------------------- derived metrics ------------------------- */

export const agentOf = (lead) =>
  lead.agents?.[0]?.name ?? lead.assigned_to?.name ?? "Unassigned";

export const statusOf = (lead) =>
  typeof lead.status === "string" ? lead.status : lead.status?.name ?? "Unknown";

/**
 * First genuine human touch. Deliberately NOT last_updated, because any
 * field edit or automation bumps that. A note carries date + user_name,
 * so it is the only thing that proves a person did something.
 */
export function firstTouchAt(lead) {
  if (!lead.notes?.length) return null;
  const times = lead.notes
    .map((n) => new Date(n.date ?? n.created_at).getTime())
    .filter((t) => !Number.isNaN(t));
  return times.length ? new Date(Math.min(...times)) : null;
}

export function hoursToFirstTouch(lead) {
  const t = firstTouchAt(lead);
  if (!t) return null;
  return (t - new Date(lead.created_at)) / 3_600_000;
}

export const isUntouched = (lead) => !lead.notes?.length;

export function median(values) {
  const s = values.filter((v) => v != null).sort((a, b) => a - b);
  if (!s.length) return null;
  const m = Math.floor(s.length / 2);
  return s.length % 2 ? s[m] : (s[m - 1] + s[m]) / 2;
}

export function summarise(leads, claimsContact) {
  const byAgent = new Map();

  for (const lead of leads) {
    const name = agentOf(lead);
    if (!byAgent.has(name)) {
      byAgent.set(name, { name, total: 0, untouched: 0, ghosts: 0, touchTimes: [] });
    }
    const row = byAgent.get(name);
    row.total++;

    if (isUntouched(lead)) {
      row.untouched++;
      // Status claims contact happened, but nothing was ever logged.
      if (claimsContact.has(statusOf(lead))) row.ghosts++;
    } else {
      row.touchTimes.push(hoursToFirstTouch(lead));
    }
  }

  return [...byAgent.values()]
    .map((r) => ({
      ...r,
      median: median(r.touchTimes),
      rate: r.total ? 1 - r.untouched / r.total : 0,
    }))
    .sort((a, b) => b.ghosts - a.ghosts || b.untouched - a.untouched);
}

export const fmtHours = (h) =>
  h == null ? "—" : h < 1 ? `${Math.round(h * 60)}m` : h < 48 ? `${h.toFixed(1)}h` : `${Math.round(h / 24)}d`;

export const isoDaysAgo = (days) =>
  new Date(Date.now() - days * 86_400_000).toISOString().slice(0, 10);
