/**
 * Sample data shaped to the PropSpace lead schema, so the UI can be built
 * and tested before credentials are live. Some agents log notes reliably,
 * some barely do — that spread is the thing the dashboard exists to surface.
 */
const AGENTS = ["Adam Reyes", "Sofia Haddad", "Marcus Bell", "Priya Nair", "Tom Whitfield", "Layla Aziz"];
const STATUSES = ["Not contacted", "Attempted contact", "Contacted", "Viewing booked", "Negotiating", "Unqualified"];
const SOURCES = ["Property Finder", "Bayut", "Meta", "Google", "Website", "Referral"];
const DILIGENCE = {
  "Adam Reyes": 0.9, "Sofia Haddad": 0.85, "Marcus Bell": 0.35,
  "Priya Nair": 0.8, "Tom Whitfield": 0.25, "Layla Aziz": 0.6,
};

let seed = 20260730;
const rand = () => { seed = (seed * 1103515245 + 12345) % 2147483648; return seed / 2147483648; };

export function mockLeads(count = 160) {
  seed = 20260730;
  const now = Date.now();
  return Array.from({ length: count }, (_, i) => {
    const agent = AGENTS[Math.floor(rand() * AGENTS.length)];
    const status = STATUSES[Math.floor(rand() * STATUSES.length)];
    const created = new Date(now - Math.floor(rand() * 60 * 24) * 3_600_000);
    const logged = rand() < DILIGENCE[agent] && status !== "Not contacted";
    return {
      id: `L-${1000 + i}`,
      reference: `AAR-${1000 + i}`,
      agents: [{ name: agent }],
      status,
      source: SOURCES[Math.floor(rand() * SOURCES.length)],
      in_lead_pool: rand() < 0.06,
      created_at: created.toISOString(),
      last_updated: created.toISOString(),
      notes: logged
        ? [{
            date: new Date(created.getTime() + Math.floor(rand() * 60) * 3_600_000).toISOString(),
            user_name: agent,
            note: "Called, discussed requirements.",
          }]
        : [],
    };
  });
}

export const MOCK_STATUSES = STATUSES;
