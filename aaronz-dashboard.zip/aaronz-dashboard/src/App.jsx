import React, { useState, useEffect, useMemo } from "react";
import {
  BarChart3, Calendar, Users, Database, Building2, Briefcase, Layers,
  Megaphone, Settings, Clock, AlertTriangle, UserX, Inbox, Download,
  RefreshCw, Wifi, WifiOff,
} from "lucide-react";
import {
  fetchLeads, agentOf, statusOf, isUntouched, hoursToFirstTouch,
  median, summarise, fmtHours, isoDaysAgo,
} from "./propspace.js";
import { mockLeads, MOCK_STATUSES } from "./mock.js";

/** Statuses that imply a human made contact. Update once you've pulled
 *  /options/lead-statuses from the live account. */
const CLAIMS_CONTACT = new Set(["Contacted", "Viewing booked", "Negotiating"]);

/* ------------------------------ atoms ------------------------------ */

const Card = ({ children, className = "" }) => (
  <div className={`bg-white border border-slate-200 rounded-2xl ${className}`}>{children}</div>
);

function Metric({ icon: Icon, tint, label, period, value, sub, alert }) {
  return (
    <Card className="p-5">
      <div className="flex items-start justify-between">
        <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${tint}`}>
          <Icon className="w-5 h-5" strokeWidth={2} />
        </div>
        {alert && (
          <span className="text-xs font-medium px-2 py-1 rounded-lg bg-rose-50 text-rose-700">{alert}</span>
        )}
      </div>
      <p className="mt-4 text-sm font-medium text-slate-700">{label}</p>
      <p className="text-xs text-slate-400 mt-0.5">{period}</p>
      <p className="mt-3 text-4xl font-bold text-slate-900 tracking-tight">{value}</p>
      {sub && <p className="mt-2 text-xs text-slate-500">{sub}</p>}
    </Card>
  );
}

const NavItem = ({ icon: Icon, label, active }) => (
  <div className={`flex items-center gap-3 px-4 py-2.5 rounded-xl text-sm cursor-pointer ${
    active ? "bg-white/10 text-white font-medium" : "text-slate-400 hover:text-slate-200"}`}>
    <Icon className="w-4 h-4" strokeWidth={2} /><span>{label}</span>
  </div>
);

/* ------------------------------ app ------------------------------ */

export default function App() {
  const [live, setLive] = useState(false);
  const [days, setDays] = useState(30);
  const [agentFilter, setAgentFilter] = useState("All agents");
  const [raw, setRaw] = useState(() => mockLeads());
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  async function load() {
    if (!live) { setRaw(mockLeads()); setError(null); return; }
    setLoading(true); setError(null);
    try {
      const rows = await fetchLeads({ from: isoDaysAgo(days), to: isoDaysAgo(0) });
      setRaw(rows);
      if (!rows.length) setError("Connected, but the API returned no leads for this range.");
    } catch (e) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { load(); /* eslint-disable-next-line */ }, [live, days]);

  const cutoff = useMemo(() => Date.now() - days * 86_400_000, [days]);

  const leads = useMemo(
    () => raw.filter((l) =>
      new Date(l.created_at).getTime() >= cutoff &&
      (agentFilter === "All agents" || agentOf(l) === agentFilter)),
    [raw, cutoff, agentFilter]
  );

  const agentNames = useMemo(
    () => [...new Set(raw.map(agentOf))].sort(), [raw]
  );

  const statusList = useMemo(() => {
    const found = [...new Set(raw.map(statusOf))];
    return live ? found : MOCK_STATUSES;
  }, [raw, live]);

  const untouched = leads.filter(isUntouched);
  const ghosts = leads.filter((l) => isUntouched(l) && CLAIMS_CONTACT.has(statusOf(l)));
  const pool = leads.filter((l) => l.in_lead_pool);
  const med = median(leads.map(hoursToFirstTouch));

  const statusCounts = statusList.map((s) => ({
    status: s, count: leads.filter((l) => statusOf(l) === s).length,
  }));
  const maxStatus = Math.max(...statusCounts.map((s) => s.count), 1);

  const byAgent = useMemo(() => summarise(leads, CLAIMS_CONTACT), [leads]);

  const period = `Last ${days} days`;
  const ctrl = "flex items-center gap-2 bg-white border border-slate-200 rounded-xl px-3 py-2 text-sm text-slate-700";

  return (
    <div className="min-h-screen bg-slate-50 flex">
      <aside className="w-56 bg-slate-900 flex-shrink-0 hidden lg:flex flex-col py-6">
        <div className="px-5 pb-6">
          <p className="text-white font-semibold text-lg tracking-tight">Aaronz &amp; Co.</p>
          <p className="text-slate-500 text-xs mt-0.5">Marketing &amp; Operations</p>
        </div>
        <nav className="px-2 space-y-1">
          <NavItem icon={BarChart3} label="Insights" active />
          <NavItem icon={Inbox} label="Lead pool" />
          <NavItem icon={Users} label="Contacts" />
          <NavItem icon={Building2} label="Listings" />
          <NavItem icon={Briefcase} label="Deals" />
          <NavItem icon={Layers} label="Off-plan" />
          <NavItem icon={Megaphone} label="Campaigns" />
          <NavItem icon={Database} label="Database" />
          <NavItem icon={Settings} label="Settings" />
        </nav>
      </aside>

      <main className="flex-1 min-w-0 px-6 lg:px-10 py-8">
        <div className="flex flex-wrap items-start justify-between gap-4 mb-6">
          <div>
            <p className="text-sm text-slate-500">Lead performance</p>
            <h1 className="text-2xl font-bold text-slate-900 tracking-tight mt-1">
              Who is working the leads
            </h1>
          </div>
          <div className="flex items-center gap-2 flex-wrap">
            <button
              onClick={() => setLive(!live)}
              className={`flex items-center gap-2 rounded-xl px-3 py-2 text-sm font-medium border ${
                live ? "bg-emerald-50 border-emerald-200 text-emerald-700"
                     : "bg-white border-slate-200 text-slate-600"}`}>
              {live ? <Wifi className="w-4 h-4" /> : <WifiOff className="w-4 h-4" />}
              {live ? "Live" : "Demo"}
            </button>
            <div className={ctrl}>
              <Calendar className="w-4 h-4 text-slate-400" />
              <select value={days} onChange={(e) => setDays(Number(e.target.value))}
                      className="bg-transparent outline-none cursor-pointer">
                <option value={7}>Last 7 days</option>
                <option value={30}>Last 30 days</option>
                <option value={90}>Last 90 days</option>
              </select>
            </div>
            <div className={ctrl}>
              <Users className="w-4 h-4 text-slate-400" />
              <select value={agentFilter} onChange={(e) => setAgentFilter(e.target.value)}
                      className="bg-transparent outline-none cursor-pointer">
                <option>All agents</option>
                {agentNames.map((a) => <option key={a}>{a}</option>)}
              </select>
            </div>
            <button onClick={load} className={`${ctrl} hover:bg-slate-50`}>
              <RefreshCw className={`w-4 h-4 text-slate-400 ${loading ? "animate-spin" : ""}`} />
              Refresh
            </button>
            <button className={`${ctrl} hover:bg-slate-50`}>
              <Download className="w-4 h-4 text-slate-400" />Export
            </button>
          </div>
        </div>

        {error && (
          <div className="mb-4 px-4 py-3 rounded-xl bg-rose-50 border border-rose-200 text-sm text-rose-800">
            <span className="font-medium">Couldn't load from PropSpace.</span>{" "}
            {error}{" "}
            <span className="text-rose-600">Check .env, then the response shape in propspace.js.</span>
          </div>
        )}

        <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
          <Metric icon={Inbox} tint="bg-violet-50 text-violet-600"
            label="Leads received" period={period} value={leads.length}
            sub={`${pool.length} still sitting in the lead pool`} />
          <Metric icon={UserX} tint="bg-rose-50 text-rose-600"
            label="Never touched" period="No note logged by anyone" value={untouched.length}
            alert={leads.length ? `${Math.round(untouched.length / leads.length * 100)}% of leads` : null}
            sub="Nobody has recorded any contact at all" />
          <Metric icon={Clock} tint="bg-sky-50 text-sky-600"
            label="Median time to first touch" period="Lead created to first note"
            value={fmtHours(med)} sub="Measured only on leads that were touched" />
          <Metric icon={AlertTriangle} tint="bg-amber-50 text-amber-600"
            label="Marked contacted, no activity" period="Status says one thing, CRM says another"
            value={ghosts.length} sub="These are the ones worth asking about" />
        </div>

        <div className="grid grid-cols-1 xl:grid-cols-3 gap-4 mt-4">
          <Card className="xl:col-span-1 p-5">
            <p className="text-sm font-semibold text-slate-900">Status breakdown</p>
            <p className="text-xs text-slate-400 mt-0.5">{period}</p>
            <div className="mt-5 space-y-3">
              {statusCounts.map((s) => (
                <div key={s.status}>
                  <div className="flex justify-between text-sm mb-1.5">
                    <span className="text-slate-600">{s.status}</span>
                    <span className="text-slate-900 font-semibold">{s.count}</span>
                  </div>
                  <div className="h-2 bg-slate-100 rounded-full overflow-hidden">
                    <div className={`h-full rounded-full ${
                        /not contacted/i.test(s.status) ? "bg-rose-400" : "bg-violet-400"}`}
                      style={{ width: `${(s.count / maxStatus) * 100}%` }} />
                  </div>
                </div>
              ))}
            </div>
          </Card>

          <Card className="xl:col-span-2 overflow-hidden">
            <div className="p-5 pb-4">
              <p className="text-sm font-semibold text-slate-900">By agent</p>
              <p className="text-xs text-slate-400 mt-0.5">
                Sorted by leads marked contacted with nothing logged
              </p>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="text-left text-xs text-slate-500 border-y border-slate-200 bg-slate-50">
                    <th className="px-5 py-2.5 font-medium">Agent</th>
                    <th className="px-3 py-2.5 font-medium text-right">Leads</th>
                    <th className="px-3 py-2.5 font-medium text-right">Untouched</th>
                    <th className="px-3 py-2.5 font-medium text-right">Median touch</th>
                    <th className="px-3 py-2.5 font-medium text-right">No activity</th>
                    <th className="px-5 py-2.5 font-medium w-32">Worked</th>
                  </tr>
                </thead>
                <tbody>
                  {byAgent.map((a) => (
                    <tr key={a.name} className="border-b border-slate-100 last:border-0">
                      <td className="px-5 py-3 font-medium text-slate-900">{a.name}</td>
                      <td className="px-3 py-3 text-right text-slate-600">{a.total}</td>
                      <td className="px-3 py-3 text-right text-slate-600">{a.untouched}</td>
                      <td className="px-3 py-3 text-right text-slate-600">{fmtHours(a.median)}</td>
                      <td className="px-3 py-3 text-right">
                        {a.ghosts > 0
                          ? <span className="inline-block px-2 py-0.5 rounded-lg bg-amber-50 text-amber-700 font-semibold">{a.ghosts}</span>
                          : <span className="text-slate-300">0</span>}
                      </td>
                      <td className="px-5 py-3">
                        <div className="flex items-center gap-2">
                          <div className="flex-1 h-2 bg-slate-100 rounded-full overflow-hidden">
                            <div className={`h-full rounded-full ${
                                a.rate > 0.75 ? "bg-emerald-400" : a.rate > 0.5 ? "bg-amber-400" : "bg-rose-400"}`}
                              style={{ width: `${a.rate * 100}%` }} />
                          </div>
                          <span className="text-xs text-slate-500 w-9 text-right">{Math.round(a.rate * 100)}%</span>
                        </div>
                      </td>
                    </tr>
                  ))}
                  {!byAgent.length && (
                    <tr><td colSpan={6} className="px-5 py-8 text-center text-sm text-slate-400">
                      No leads in this range.
                    </td></tr>
                  )}
                </tbody>
              </table>
            </div>
          </Card>
        </div>

        <Card className="mt-4 p-5">
          <div className="flex items-center justify-between mb-4">
            <div>
              <p className="text-sm font-semibold text-slate-900">Needs a call today</p>
              <p className="text-xs text-slate-400 mt-0.5">Longest-waiting leads with no note logged</p>
            </div>
            <span className="text-xs text-slate-500">{untouched.length} total</span>
          </div>
          <div className="space-y-2">
            {untouched
              .slice()
              .sort((a, b) => new Date(a.created_at) - new Date(b.created_at))
              .slice(0, 6)
              .map((l) => {
                const age = (Date.now() - new Date(l.created_at)) / 3_600_000;
                return (
                  <div key={l.id} className="flex items-center justify-between px-4 py-3 bg-slate-50 rounded-xl">
                    <div className="flex items-center gap-4 min-w-0">
                      <span className="text-sm font-medium text-slate-900 w-24 flex-shrink-0">
                        {l.reference ?? l.id}
                      </span>
                      <span className="text-sm text-slate-500 w-32 truncate">{agentOf(l)}</span>
                      <span className="text-xs text-slate-400 hidden sm:inline">{l.source}</span>
                    </div>
                    <div className="flex items-center gap-3 flex-shrink-0">
                      <span className="text-xs text-slate-500 hidden sm:inline">{statusOf(l)}</span>
                      <span className="text-xs font-semibold px-2 py-1 rounded-lg bg-rose-50 text-rose-700">
                        {fmtHours(age)} old
                      </span>
                    </div>
                  </div>
                );
              })}
            {!untouched.length && (
              <p className="text-sm text-slate-400 py-6 text-center">
                Every lead in this range has been touched. Worth a screenshot.
              </p>
            )}
          </div>
        </Card>

        <p className="text-xs text-slate-400 mt-6">
          {live ? "Live from PropSpace." : "Demo data shaped to the PropSpace lead schema."}{" "}
          Status is self-reported; first touch is derived from the notes array.
        </p>
      </main>
    </div>
  );
}
