# Lead performance dashboard

Shows who is actually working the leads, not just who says they are.

## Run it

```bash
npm install
cp .env.example .env      # add your PropSpace client id + secret
npm run dev               # http://localhost:5173
```

It boots in **Demo** mode with sample data. Flip the toggle top-right to
**Live** once your credentials are in `.env`.

## How the credentials are handled

`vite.config.js` contains a small dev middleware. The browser calls
`/ps/leads`, Node does the OAuth2 client-credentials exchange, caches the
token, and forwards the request with the Bearer header attached.

Two consequences worth knowing:

- No CORS, because the browser only ever talks to localhost.
- The client secret stays in Node and never enters the bundle.

For production, move that same logic into a Cloudflare Worker. The front end
doesn't change, only the base URL.

## The metric that matters

Status is self-reported. Anyone can flip a lead to *Contacted* without
picking up the phone.

The `notes` array carries `date` and `user_name`, so it is the only field
that proves a human did something. Deliberately **not** `last_updated` —
that bumps on any field edit or automation.

So the dashboard tracks two things side by side:

- **Status** — what the broker says
- **First touch** — when a note was actually logged

The gap between them is the "marked contacted, no activity" figure, and it
is the number Billie is actually annoyed about. Everything else on the page
is standard CRM reporting.

## Before you trust the live numbers

1. **Check the response envelope.** The spec defines `LeadListResponse` but
   not the exact key names. `unwrap()` in `propspace.js` handles
   `data` / `leads` / bare arrays. Log one raw response and tighten it.
2. **Check the pagination params.** `page` / `per_page` are assumed. Confirm
   against your account.
3. **Pull the real statuses.** `fetchLeadStatuses()` is wired up but the UI
   currently uses the demo list. Swap it in and update `CLAIMS_CONTACT` to
   match the statuses that actually imply contact happened.

## Baseline first

Before changing anything operationally, export a snapshot of today's numbers.
In six months that snapshot is the difference between "things feel better"
and "median first touch went from 14 hours to 90 minutes."
