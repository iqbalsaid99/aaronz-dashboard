import { defineConfig, loadEnv } from "vite";
import react from "@vitejs/plugin-react";

/**
 * Dev-only PropSpace proxy.
 *
 * The browser calls /ps/... on localhost. This middleware does the OAuth2
 * token exchange in Node, caches the token, and forwards the request with the
 * Bearer header attached. Two things that buys you:
 *   1. No CORS, because the browser only ever talks to localhost.
 *   2. The client secret never reaches the browser bundle.
 *
 * In production this same logic belongs in a Cloudflare Worker.
 */
function propspace(env) {
  let token = null;
  let expiresAt = 0;

  async function getToken() {
    if (token && Date.now() < expiresAt - 60_000) return token;

    const res = await fetch("https://api.propspace.com/auth/token", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        grant_type: "client_credentials",
        client_id: env.PROPSPACE_CLIENT_ID,
        client_secret: env.PROPSPACE_CLIENT_SECRET,
      }),
    });

    if (!res.ok) {
      throw new Error(`auth failed ${res.status}: ${await res.text()}`);
    }

    const data = await res.json();
    token = data.access_token;
    expiresAt = Date.now() + (data.expires_in ?? 3600) * 1000;
    console.log("[propspace] token refreshed");
    return token;
  }

  return {
    name: "propspace-dev-proxy",
    configureServer(server) {
      server.middlewares.use("/ps", async (req, res) => {
        try {
          const t = await getToken();
          const upstream = await fetch("https://api.propspace.com" + req.url, {
            headers: { Authorization: `Bearer ${t}`, Accept: "application/json" },
          });
          const body = await upstream.text();
          res.statusCode = upstream.status;
          res.setHeader("Content-Type", "application/json");
          res.end(body);
        } catch (err) {
          console.error("[propspace]", err);
          res.statusCode = 502;
          res.setHeader("Content-Type", "application/json");
          res.end(JSON.stringify({ error: String(err) }));
        }
      });
    },
  };
}

export default defineConfig(({ mode }) => {
  const env = loadEnv(mode, process.cwd(), "");
  return {
    plugins: [react(), propspace(env)],
    server: { port: 5173 },
  };
});
